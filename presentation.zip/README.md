# Співбесіда для експерта

<table>
<tr>
    <td>
        Ця презентація допоможе вам у підготовці до співбесіди.<br/>
        Так, якщо ви проводите співбесіди, то вам також треба готуватися.
    </td>
    <td>
        <img src="pictures/icon-192x192.png" alt="Anton's logo"/>
    </td>
</tr>
</table>

## Презентація

https://antonshevchuk.github.io/interview/

## Локальна презентація

Ви маєте можливість зробити свою локальну копію з репозіторію та запустити:

```
npm install
npm start
```

## Про презентацію
Презентація створена за допомогою [Shower](https://shwr.me/).  
Автор іконок [Freepik](https://www.freepik.com).